# -*- coding: utf8 -*-
import json
import requests
from bs4 import BeautifulSoup
import re
import os

def zzu(uid, upw):
    headers = {'user-agent': 'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6010 Build/QKQ1.190716.003; wv) '
                             'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.62 XWEB/2469'
                             ' MMWEBSDK/200801 Mobile Safari/537.36 MMWEBID/6013 MicroMessenger/7.0.18.1723(0x27001241)'
                             ' Process/toolsmp WeChat/arm64 GPVersion/1 NetType/4G Language/zh_CN ABI/arm64'}
    session = requests.session()
    url = 'https://jksb.v.zzu.edu.cn/vls6sss/zzujksb.dll/login'
    data = {
        'uid': uid,
        'upw': upw,
        'smbtn': '进入健康状况上报平台',
        'hh28': '763'
    }
    # 登录系统
    response = session.post(url, data, headers=headers)
    print('登录', response.status_code)
    html = str(response.content, 'utf-8')
    url = html[html.find('window.location=') + 17: html.find('"}}')]
    ptopid = url[url.find('ptopid=') + 7: url.find('&sid')]
    response = session.get(url)
    print('获取首页顶部', response.status_code)
    html = str(response.content, 'utf-8')
    soup = BeautifulSoup(html, 'html.parser')
    url = soup.iframe['src']
    print(url)
    # 获取首页信息
    response = session.get(url)
    print('获取首页', response.status_code)
    html = str(response.content, 'utf-8')
    fun18 = re.search("\"fun18\" value=.*? />", html).group()[15:-4]
    if html.find("今日您已经填报过了") >= 0:
        session.close()
        print("已经填报")
        return 0

    soup = BeautifulSoup(html, 'html.parser')
    sid = soup.find_all('input')[-1]['value']
    url = 'https://jksb.v.zzu.edu.cn/vls6sss/zzujksb.dll/jksb'
    data = {
        'day6': 'b',
        'did': '1',
        'men6': 'a',
        'ptopid': ptopid,
        'sid': sid
    }
    # 获取信息记录页
    response = session.post(url, data=data)
    print('信息记录页', response.status_code)
    html = str(response.content, 'utf-8')
    soup = BeautifulSoup(html, 'html.parser')
    sid = soup.find_all('input')[-1]['value']
    url = 'https://jksb.v.zzu.edu.cn/vls6sss/zzujksb.dll/jksb'
    data = {
        'day6': 'b',
        'did': '2',
        'men6': 'a',
        'myvs_1': '否',
        'myvs_2': '否',
        'myvs_3': '否',
        'myvs_4': '否',
        'myvs_5': '否',
        'myvs_7': '否',
        'myvs_8': '否',
        'myvs_9': 'y',
        'myvs_11': '否',
        'myvs_12': '否',
        'myvs_13': '否',
        'myvs_15': '否',
        'myvs_13a': 41,
        'myvs_13b': 4101,
        'myvs_13c': '郑州',
        'myvs_24': '否',
        'myvs_14b': '郑州',
        'jingdu': 0.0000,
        'weidu': 0.0000,
        'memo22': '[待定]',
        'myvs_26': 5,
        'myvs_30': '在校',
        'ptopid': ptopid,
        'sid': sid,
        'fun18': fun18
    }
    # 进行填报
    response = session.post(url, data)
    print('状态页', response.status_code)
    html = str(response.content, 'utf-8')
    print(html)
    session.close()
    if html.find("冀娟") >= 0:
        print("已经填报")
        return 0
    else:
        return -1


def main_handler(event, context):
    print("Received event: " + json.dumps(event, indent = 2))
    print("Received context: " + str(context))
    print("Hello world")
    uid = os.environ.get('uid')
    upw = os.environ.get('upw')
    return zzu(uid, upw)
